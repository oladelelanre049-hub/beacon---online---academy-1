# Beacon Online Academy — Full-stack foundation

A working FastAPI + SQLAlchemy web application with SQLite persistence, public responsive site, consultation intake, session login, admin-controlled account creation, tutor/student assignments, parent/child links, assessments and lessons. Access checks are enforced server-side.

## Local startup

```bash
cd beacon-academy
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export SESSION_SECRET="$(python -c 'import secrets;print(secrets.token_urlsafe(48))')"
python create_admin.py
uvicorn app:app --reload
```

Visit http://127.0.0.1:8000 and http://127.0.0.1:8000/docs (protected endpoints require login). Admin creates users through `/api/users`, assigns students with `/api/assign`, and links parents with `/api/link-parent`.

## Production readiness

**This is a functional foundation, not a production-ready school platform.** Before enrolling children, add HTTPS, durable managed PostgreSQL, CSRF protection, rate limiting, password reset and email verification, audit logging, safeguarding workflows, file storage, backups, stronger validation, automated tests, deployment configuration, and privacy/legal review. Never put real student information into a publicly accessible test deployment. Session secret must be stable and securely managed; set `HTTPS_ONLY=1` behind HTTPS. Replace placeholder/co-founder imagery and confirm consent before public use.

Not implemented: live video, payment collection, attendance, messaging, quizzes with question banks, report-card exports, admin graphical user management, notifications and automated schedules.
