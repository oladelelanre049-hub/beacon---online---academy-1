import os, secrets
from datetime import datetime
from fastapi import FastAPI, Depends, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, DateTime, Float, Text, UniqueConstraint
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from passlib.context import CryptContext
from starlette.middleware.sessions import SessionMiddleware

DB=os.getenv('DATABASE_URL','sqlite:///./beacon.db')
engine=create_engine(DB,connect_args={'check_same_thread':False} if DB.startswith('sqlite') else {})
SessionLocal=sessionmaker(bind=engine)
Base=declarative_base()
pwd=CryptContext(schemes=['bcrypt'],deprecated='auto')
class User(Base):
 __tablename__='users'
 id=Column(Integer,primary_key=True); name=Column(String(150),nullable=False); email=Column(String(255),unique=True,nullable=False); password_hash=Column(String(255),nullable=False); role=Column(String(20),nullable=False); created=Column(DateTime,default=datetime.utcnow)
class Assignment(Base):
 __tablename__='assignments'; id=Column(Integer,primary_key=True); tutor_id=Column(Integer,ForeignKey('users.id'),nullable=False); student_id=Column(Integer,ForeignKey('users.id'),nullable=False); __table_args__=(UniqueConstraint('tutor_id','student_id'),)
class ParentChild(Base):
 __tablename__='parent_children'; id=Column(Integer,primary_key=True); parent_id=Column(Integer,ForeignKey('users.id'),nullable=False); student_id=Column(Integer,ForeignKey('users.id'),nullable=False); __table_args__=(UniqueConstraint('parent_id','student_id'),)
class Assessment(Base):
 __tablename__='assessments'; id=Column(Integer,primary_key=True); student_id=Column(Integer,ForeignKey('users.id'),nullable=False); tutor_id=Column(Integer,ForeignKey('users.id'),nullable=False); subject=Column(String(100),nullable=False); score=Column(Float,nullable=False); maximum=Column(Float,nullable=False); feedback=Column(Text,default=''); created=Column(DateTime,default=datetime.utcnow)
class Lesson(Base):
 __tablename__='lessons'; id=Column(Integer,primary_key=True); student_id=Column(Integer,ForeignKey('users.id'),nullable=False); tutor_id=Column(Integer,ForeignKey('users.id'),nullable=False); title=Column(String(200),nullable=False); scheduled_at=Column(String(40),nullable=False); status=Column(String(30),default='scheduled')
class Consultation(Base):
 __tablename__='consultations'; id=Column(Integer,primary_key=True); parent_name=Column(String(150)); email=Column(String(255)); phone=Column(String(40)); learner_age=Column(String(20)); programme=Column(String(100)); message=Column(Text); created=Column(DateTime,default=datetime.utcnow)
Base.metadata.create_all(engine)
app=FastAPI(title='Beacon Online Academy')
app.add_middleware(SessionMiddleware,secret_key=os.getenv('SESSION_SECRET',secrets.token_urlsafe(48)),same_site='lax',https_only=os.getenv('HTTPS_ONLY','0')=='1')
app.mount('/static',StaticFiles(directory='static'),name='static')
def db():
 with SessionLocal() as s: yield s
def current(request:Request,s:Session=Depends(db)):
 uid=request.session.get('uid'); u=s.get(User,uid) if uid else None
 if not u: raise HTTPException(401,'Please sign in')
 return u
def admin(u=Depends(current)):
 if u.role!='admin':raise HTTPException(403,'Admin only')
 return u
def accessible(s,u,student_id):
 if u.role=='admin':return True
 if u.role=='student':return u.id==student_id
 if u.role=='tutor':return s.query(Assignment).filter_by(tutor_id=u.id,student_id=student_id).first() is not None
 if u.role=='parent':return s.query(ParentChild).filter_by(parent_id=u.id,student_id=student_id).first() is not None
 return False
@app.get('/',response_class=HTMLResponse)
def home():return open('static/index.html').read()
@app.post('/consultations')
def consultation(parent_name:str=Form(...),email:str=Form(...),phone:str=Form(...),learner_age:str=Form(''),programme:str=Form(''),message:str=Form(''),s:Session=Depends(db)):
 s.add(Consultation(parent_name=parent_name,email=email,phone=phone,learner_age=learner_age,programme=programme,message=message));s.commit();return RedirectResponse('/?submitted=1',303)
@app.post('/login')
def login(request:Request,email:str=Form(...),password:str=Form(...),s:Session=Depends(db)):
 u=s.query(User).filter_by(email=email.lower().strip()).first()
 if not u or not pwd.verify(password,u.password_hash):raise HTTPException(401,'Invalid credentials')
 request.session.clear();request.session['uid']=u.id;return RedirectResponse('/dashboard',303)
@app.post('/logout')
def logout(request:Request):request.session.clear();return RedirectResponse('/',303)
@app.get('/dashboard',response_class=HTMLResponse)
def dashboard(u:User=Depends(current)):
 return open('static/dashboard.html').read().replace('__USER__',u.name.replace('&','&amp;').replace('<','&lt;')).replace('__ROLE__',u.role)
@app.get('/api/me')
def me(u:User=Depends(current)):return {'id':u.id,'name':u.name,'email':u.email,'role':u.role}
@app.get('/api/students')
def students(u:User=Depends(current),s:Session=Depends(db)):
 q=s.query(User).filter_by(role='student')
 if u.role=='tutor':q=q.join(Assignment,Assignment.student_id==User.id).filter(Assignment.tutor_id==u.id)
 elif u.role=='parent':q=q.join(ParentChild,ParentChild.student_id==User.id).filter(ParentChild.parent_id==u.id)
 elif u.role!='admin':q=q.filter(User.id==u.id)
 return [{'id':v.id,'name':v.name} for v in q.all()]
@app.get('/api/students/{student_id}')
def student(student_id:int,u:User=Depends(current),s:Session=Depends(db)):
 v=s.get(User,student_id)
 if not v or v.role!='student':raise HTTPException(404)
 if not accessible(s,u,student_id):raise HTTPException(403)
 return {'id':v.id,'name':v.name,'assessments':[{'subject':a.subject,'score':a.score,'maximum':a.maximum,'feedback':a.feedback} for a in s.query(Assessment).filter_by(student_id=student_id).all()],'lessons':[{'title':l.title,'scheduled_at':l.scheduled_at,'status':l.status} for l in s.query(Lesson).filter_by(student_id=student_id).all()]}
@app.post('/api/users')
def create_user(name:str=Form(...),email:str=Form(...),password:str=Form(...),role:str=Form(...),u=Depends(admin),s:Session=Depends(db)):
 if role not in ('admin','tutor','student','parent') or len(password)<12:raise HTTPException(400,'Invalid role or password shorter than 12 characters')
 if s.query(User).filter_by(email=email.lower().strip()).first():raise HTTPException(409,'Email exists')
 v=User(name=name,email=email.lower().strip(),password_hash=pwd.hash(password),role=role);s.add(v);s.commit();return {'id':v.id}
@app.post('/api/assign')
def assign(tutor_id:int=Form(...),student_id:int=Form(...),u=Depends(admin),s:Session=Depends(db)):
 t=s.get(User,tutor_id);v=s.get(User,student_id)
 if not t or t.role!='tutor' or not v or v.role!='student':raise HTTPException(400,'Invalid tutor or student')
 if not s.query(Assignment).filter_by(tutor_id=tutor_id,student_id=student_id).first():s.add(Assignment(tutor_id=tutor_id,student_id=student_id));s.commit()
 return {'ok':True}
@app.post('/api/link-parent')
def link_parent(parent_id:int=Form(...),student_id:int=Form(...),u=Depends(admin),s:Session=Depends(db)):
 p=s.get(User,parent_id);v=s.get(User,student_id)
 if not p or p.role!='parent' or not v or v.role!='student':raise HTTPException(400,'Invalid parent or student')
 if not s.query(ParentChild).filter_by(parent_id=parent_id,student_id=student_id).first():s.add(ParentChild(parent_id=parent_id,student_id=student_id));s.commit()
 return {'ok':True}
@app.post('/api/assessments')
def add_assessment(student_id:int=Form(...),subject:str=Form(...),score:float=Form(...),maximum:float=Form(...),feedback:str=Form(''),u:User=Depends(current),s:Session=Depends(db)):
 if u.role not in ('admin','tutor') or not accessible(s,u,student_id):raise HTTPException(403)
 if maximum<=0 or score<0 or score>maximum:raise HTTPException(400,'Invalid score')
 s.add(Assessment(student_id=student_id,tutor_id=u.id,subject=subject,score=score,maximum=maximum,feedback=feedback));s.commit();return {'ok':True}
@app.post('/api/lessons')
def add_lesson(student_id:int=Form(...),title:str=Form(...),scheduled_at:str=Form(...),u:User=Depends(current),s:Session=Depends(db)):
 if u.role not in ('admin','tutor') or not accessible(s,u,student_id):raise HTTPException(403)
 s.add(Lesson(student_id=student_id,tutor_id=u.id,title=title,scheduled_at=scheduled_at));s.commit();return {'ok':True}
@app.get('/api/admin/consultations')
def consultations(u=Depends(admin),s:Session=Depends(db)):
 return [{'id':c.id,'name':c.parent_name,'email':c.email,'programme':c.programme} for c in s.query(Consultation).order_by(Consultation.id.desc()).all()]
