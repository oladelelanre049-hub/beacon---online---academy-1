import getpass
from app import SessionLocal,User,pwd
with SessionLocal() as s:
 email=input('Admin email: ').strip().lower()
 if s.query(User).filter_by(email=email).first():raise SystemExit('Email already exists')
 name=input('Admin name: ').strip()
 password=getpass.getpass('Admin password (12+ characters): ')
 if len(password)<12:raise SystemExit('Password must have 12+ characters')
 s.add(User(name=name,email=email,password_hash=pwd.hash(password),role='admin'));s.commit()
 print('Admin created. Keep credentials private.')
